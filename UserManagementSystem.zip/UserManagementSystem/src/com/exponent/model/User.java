package com.exponent.model;

public class User {
	
	private int uid;
	private String uname;
	private String uaddress;
	private double usalary;
	private String uGender;
	private int userNo;
	
	
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUaddress() {
		return uaddress;
	}
	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}
	public double getUsalary() {
		return usalary;
	}
	public void setUsalary(double usalary) {
		this.usalary = usalary;
	}
	public String getuGender() {
		return uGender;
	}
	public void setuGender(String uGender) {
		this.uGender = uGender;
	}
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	
	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", uaddress=" + uaddress + ", usalary=" + usalary
				+ ", uGender=" + uGender + ", userNo=" + userNo + "]";
	}
	
	
	
	

}
