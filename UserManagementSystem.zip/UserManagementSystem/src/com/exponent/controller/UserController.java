package com.exponent.controller;

import com.exponent.service.*;
import com.exponent.serviceimplementation.*;
import java.util.Scanner;

public class UserController {
	
	public static void main(String[] args) {
		
		System.out.println("************Welcome TO UserManagementSystem*************");
		
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		UserService user = new UserServiceImpl();
		
		while(flag) {
			System.out.println("----------------------------------");
			System.out.println("1: Add User Details :            |");
			System.out.println("2: Display All User :            |");
			System.out.println("3: Display Single User :         |");
			System.out.println("4: Update User Details :         |");
			System.out.println("5: Delete User Details :         |");
			System.out.println("6: Exit :                        |");
			System.out.println("----------------------------------");
			System.out.println();
			
			System.out.println("Enter your choice between 1 to 6" + " :");
			int ch = sc.nextInt();		
			
			switch(ch) {
			case 1:
				user.userAdd();
				break;
			case 2:
				user.displayAllUser();
				break;
			case 3:
				user.displaySingleUser();
				break;
			case 4:
				user.updateUserDetails();
				break;
			case 5:
				user.deleteUserDetails();
				user.displayAllUser();
				break;
			case 6:
				flag = false;
				break;
				default:
					System.out.println("Entered invalid choice pls enter correct choice");
					break;
				
			}
		
	   }

	 }
}
