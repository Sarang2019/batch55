package com.exponent.serviceimplementation;

import java.util.Scanner;
import com.exponent.model.User;
import com.exponent.service.UserService;

public class UserServiceImpl implements UserService {

	 User[] u = new User[5];
	 Scanner sc = new Scanner(System.in);
//	 UserService us = new UserServiceImpl();
	 User user = new User();
	 	
	public void userAdd() {
	 	System.out.println("Enter how many user you want to add: ");
		int n = sc.nextInt();
		
		for(int i=0; i<n; i++) {
			
			User user = new User();
			
			System.out.println("Enter user Id: ");
			user.setUid(sc.nextInt());
			
			System.out.println("Enter user name: ");
			user.setUname(sc.next());
			
			System.out.println("Enter user address: ");
			user.setUaddress(sc.next());
			
			System.out.println("Enter user salary: ");
			user.setUsalary(sc.nextDouble());
			
			System.out.println("Enter user Gender: ");
			user.setuGender(sc.next());
			
			System.out.println("Enter user ph Number: ");
			user.setUserNo(sc.nextInt());
			
			u[i] = user;
			
			System.out.println("---------User Added--------");
			
		}
				
		
	}

	
	public void displayAllUser() {
		
		System.out.println("--------All User Details-------");
		for (User user : u) {
			if(user != null)
			System.out.println(user);
		}
		
	}

	
	public void displaySingleUser() {
		System.out.println("Enter User Id: ");
		int id = sc.nextInt();
		boolean flag = false;
		for (User user : u) {
			if(user != null && user.getUid()==id) {
				System.out.println(user);
				flag = true;
				break;
			}
//			else {
//				System.out.println("Invalid Input");
//			}
		}
		if(!flag) {
			System.out.println("Invalid Input");
		}
	}

	
	public void updateUserDetails() {
		
		UserServiceImpl userr = new UserServiceImpl();

		System.out.println("Enter User Id: ");
		int id = sc.nextInt();
		boolean f = false;
		for (User us : u) {
			if(us != null && us.getUid()==id) {
		System.out.println("Update user Details: ");
		System.out.println("1: Update user Id      : ");
		System.out.println("2: Update user name    : ");
		System.out.println("3: Update user address : ");
		System.out.println("4: Update user salary  : ");
		System.out.println("5: Exit                : ");
		
		System.out.println("Enter your choice between 1 to 4 :");
	    
		boolean flag = true;
		while(flag) {
			int up = sc.nextInt();	
			switch(up) {
			case 1:
				System.out.println("Enter new Id: ");
				user.setUid(sc.nextInt());
				break;
			case 2:
				System.out.println("Enter new name: ");
				user.setUname(sc.next());
				break;
			case 3:
				System.out.println("Enter new address: ");
				user.setUaddress(sc.next());
				break;
			case 4:
				System.out.println("Enter new salary: ");
				user.setUsalary(sc.nextDouble());
				
			case 5:
//				
				flag = false;
				break;	
			default:
				System.out.println("Entered invalid choice pls enter correct choice");
				break;	
			}
			}
			System.out.println("Updated Account Details "+ user);
			}
		}
		if(!f) {
			System.out.println("Invalid Input");
			userr.updateUserDetails();
		}
		}
		


	@Override
	public void deleteUserDetails() {
		System.out.println("Enter user Id: ");
		int id = sc.nextInt();
		boolean flag = false;
		int index =0;
		for(int i=0; i<u.length; i++) {
			if(u[i] != null && u[i].getUid()==id ) {
				index = i;
				flag=true;
				break;
			}
			
		}
		u[index] = null;
//		us.displayAllUser();	
		if(!flag) {
			System.out.println("Invalid Input");
		}
	}

	

}
